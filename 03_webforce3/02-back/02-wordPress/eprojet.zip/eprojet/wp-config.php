<?php
/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier contient les réglages de configuration suivants : réglages MySQL,
 * préfixe de table, clés secrètes, langue utilisée, et ABSPATH.
 * Vous pouvez en savoir plus à leur sujet en allant sur
 * {@link http://codex.wordpress.org/fr:Modifier_wp-config.php Modifier
 * wp-config.php}. C’est votre hébergeur qui doit vous donner vos
 * codes MySQL.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d’installation. Vous n’avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en "wp-config.php" et remplir les
 * valeurs.
 *
 * @package WordPress
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define('DB_NAME', 'eprojet');

/** Utilisateur de la base de données MySQL. */
define('DB_USER', 'root');

/** Mot de passe de la base de données MySQL. */
define('DB_PASSWORD', '');

/** Adresse de l’hébergement MySQL. */
define('DB_HOST', 'localhost');

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define('DB_CHARSET', 'utf8mb4');

/** Type de collation de la base de données.
  * N’y touchez que si vous savez ce que vous faites.
  */
define('DB_COLLATE', '');

/**#@+
 * Clés uniques d’authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clefs secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n’importe quel moment, afin d’invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '+YYU!1tM$$LfW5eVo)]Fp}%eRQJ&W*.dPz^P4H`rV`|nSAN7jn@xG>Y1<Jvf5VR.');
define('SECURE_AUTH_KEY',  '%3Lw>+=)#l$>rE?WU0(<l` =@C[0x508c!O[X>F<&uwj4[Ib+[ f9*v[zoJ@[9ZD');
define('LOGGED_IN_KEY',    'MGrb8pgIjq:,5&Doe!DZk7y;*[e;$LklPNU`57VJ2n8_XD<Ii2WzF[sG#]IIXT=+');
define('NONCE_KEY',        'uoN:43Fm/~v17gIgQ;7[dS{% QSV#ep5tfmiaWY<juw]]9_o6kke#7{N`d,OJ($g');
define('AUTH_SALT',        'R;R~ H(]#8]%5V>MDlKYsLj]O m(U]mQiHtj9zw)8a*_i{``HR?smB0mfcgDanZ9');
define('SECURE_AUTH_SALT', '._+r]00Zb.Y5F[|7a}`@<hAF,U||nLK4J.wz!hag>hxeR`* XgZ4DW%mf/;zg{4B');
define('LOGGED_IN_SALT',   '4?F@*YwK|!p,F_#5V6/6JhupepU*K_@]q,~^yJjG6>PM?B,X8K+,Q6#^GMa:5oV.');
define('NONCE_SALT',       ';OW=xN )Xc>t|DGmm,0%4n:~$8(y.K<~/vlDc.[5+*$$&z5ss&#B+|{?6~lBz_XE');
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique.
 * N’utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés !
 */
$table_prefix  = 'eprojet_';

/**
 * Pour les développeurs : le mode déboguage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l’affichage des
 * notifications d’erreurs pendant vos essais.
 * Il est fortemment recommandé que les développeurs d’extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 *
 * Pour plus d’information sur les autres constantes qui peuvent être utilisées
 * pour le déboguage, rendez-vous sur le Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* C’est tout, ne touchez pas à ce qui suit ! */

/** Chemin absolu vers le dossier de WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once(ABSPATH . 'wp-settings.php');