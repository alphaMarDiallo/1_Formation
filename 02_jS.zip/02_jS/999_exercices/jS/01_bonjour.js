// alert("bonjour js ready !");
var votreNom = window.prompt("Quel est votre Nom ?");
console.log(votreNom);

var votrePrenom = window.prompt(" Votre prénom ?");
console.log(votrePrenom);
alert("Bonjour " + votrePrenom + " " + votreNom + " " + "!");