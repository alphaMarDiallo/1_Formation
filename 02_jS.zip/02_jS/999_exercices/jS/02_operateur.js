// alert("ok");
var HT = prompt('saisissez un prix HT : ' );
var TTC = HT * 1.20;
alert('le prix ttc est : ' + TTC);
